import { useEffect, useState } from "react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000";

export default function App() {
  const [productos, setProductos] = useState([]);
  const [nombre, setNombre] = useState("");
  const [stock, setStock] = useState("");

  const cargarProductos = async () => {
    const res = await fetch(`${API_URL}/api/productos`);
    const data = await res.json();
    setProductos(data);
  };

  const crearProducto = async (e) => {
    e.preventDefault();
    await fetch(`${API_URL}/api/productos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre, stock })
    });
    setNombre("");
    setStock("");
    cargarProductos();
  };

  useEffect(() => {
    cargarProductos();
  }, []);

  return (
    <div style={{ padding: "1rem" }}>
      <h1>Inventario</h1>
      <form onSubmit={crearProducto}>
        <input
          placeholder="Nombre"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
          required
        />
        <input
          placeholder="Stock"
          value={stock}
          onChange={(e) => setStock(e.target.value)}
          type="number"
          min="0"
        />
        <button type="submit">Agregar</button>
      </form>
      <ul>
        {productos.map((p) => (
          <li key={p.id}>
            {p.nombre} — stock: {p.stock}
          </li>
        ))}
      </ul>
    </div>
  );
}