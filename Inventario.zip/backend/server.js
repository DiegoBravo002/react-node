import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Ruta de prueba
app.get("/api", (req, res) => {
  res.json({ message: "API Inventario funcionando ✅" });
});

// Ejemplo CRUD básico en memoria
let productos = [
  { id: 1, nombre: "Mouse", stock: 10 },
  { id: 2, nombre: "Teclado", stock: 5 }
];

app.get("/api/productos", (req, res) => {
  res.json(productos);
});

app.post("/api/productos", (req, res) => {
  const { nombre, stock } = req.body;
  const nuevo = { id: Date.now(), nombre, stock: Number(stock) || 0 };
  productos.push(nuevo);
  res.status(201).json(nuevo);
});

app.put("/api/productos/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = productos.findIndex(p => p.id === id);
  if (index === -1) return res.status(404).json({ error: "No encontrado" });
  productos[index] = { ...productos[index], ...req.body };
  res.json(productos[index]);
});

app.delete("/api/productos/:id", (req, res) => {
  const id = Number(req.params.id);
  productos = productos.filter(p => p.id !== id);
  res.json({ message: "Eliminado" });
});

app.listen(PORT, () => {
  console.log(`Servidor escuchando en puerto ${PORT}`);
});